(function($){
	$(function(){
	$(".multiselect").multiselect();	
});
}(jQuery));
