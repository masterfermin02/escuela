(function($){
	$(function(){
	$(".radio-uniform").uniform();	
});
}(jQuery));
