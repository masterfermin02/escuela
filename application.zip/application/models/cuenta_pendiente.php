<?Php

class cuenta_pendiente extends CI_Model {



    

        function __construct()
        {

            // Call the Model constructor

            parent::__construct();

        }
		
		function gets()
		{
			$this->db->where(' estado = "pagado" ');
			$query = $this->db->get('cuenta_pendiente');
			return $query->result_array();
		}

	

}

?>