<?Php

class Email_model extends CI_Model {
	
	function __construct()
	{

		// Call the Model constructor

		parent::__construct();
	}
	
	
	function getGrupos()
	{
		$this->db->select('id_nivel, libro');
		$query = $this->db->get('nivel_cursando');
		
		return $query->result_array();
		
	}
}