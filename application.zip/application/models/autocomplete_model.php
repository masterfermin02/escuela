<?Php
/**
 * Autocomplete_Model
 *
 * @package autocomplete
 */

class Autocomplete_Model extends CI_Model
{
    function GetAutocomplete($options = array())
    {
	    $this->db->select('nombre');
	    $this->db->like('nombre', $options['keyword'], 'after');
   		$query = $this->db->get('estudiante');
		return $query->result();
    }
}
?>