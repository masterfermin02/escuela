<?php 

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class prueva extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		
		
		$this->load->database();
		$this->load->helper('url');
		
		$this->load->model('escuela');
		
		
	}
	
	function index()
	{ 	
		$query = $this->db->query('SELECT lead_id, phone_number FROM vicidial_list_202');
		$count = 0;
		foreach ($query->result() as $row)
		{
			$phone = explode(",",$row->phone_number);
			$data = array(
                
               'phone_number' => $phone[1]
            );

			$this->db->where('lead_id', $row->lead_id);
			$this->db->update('vicidial_list_202', $data); 
			$count++;
		}
		echo "listo, registos = " + $count;

		
	}
	

}