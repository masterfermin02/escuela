<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Email extends CI_Controller {


	function __construct()
    {
        parent::__construct();
        $this->load->database();
		$this->load->helper('url');
		$this->load->library('ion_auth');
		if (!$this->ion_auth->logged_in())
		{
			redirect('auth/login');
		}
    }

    function index()
    {
    	$output = (object)array('output' => '' , 'js_files' => array() , 'css_files' => array());
		$this->load->model('email_model');
		$this->load->helper('form');
		$output->grupos = $this->email_model->getGrupos();
		
    	$this->load->view('header.php',$output);
        $this->load->view('menu');
        $this->load->view('email/email.php',$output);	
        $this->load->view('footer.php');	
    }
	
	function send()
	{
		$output = (object)array('output' => '' , 'js_files' => array() , 'css_files' => array());
		$this->load->library('email');
		
		$para = $this->input->post('para');
		$grupos = $this->input->post('grupos');
		$msj = $this->input->post('msj');
		$titulo = $this->input->post('titulo');
		
		$this->email->from('masterfermin02@gmail.com', 'Centro EBG');
		$this->email->to($para);

		$this->email->subject($titulo);
		$this->email->message($msj);
		
		if($this->email->send()){
			$this->load->view('header.php',$output);
			$this->load->view('menu');
			echo '<div class="alert alert-success" role="alert">Enviado</div>';
			 $this->load->view('footer.php');
		}else{
			$this->load->view('header.php',$output);
			$this->load->view('menu');
			echo '<div class="alert alert-error" role="alert">Error</div>';
			 $this->load->view('footer.php');
		}
	}
	
	function testSend()
	{
		
	}

}