<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-03-26 16:43:00 --> Config Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Hooks Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Utf8 Class Initialized
DEBUG - 2013-03-26 16:43:00 --> UTF-8 Support Enabled
DEBUG - 2013-03-26 16:43:00 --> URI Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Router Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Output Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Security Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Input Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-26 16:43:00 --> Language Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Loader Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Controller Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2013-03-26 16:43:00 --> Email Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2013-03-26 16:43:00 --> Helper loaded: cookie_helper
DEBUG - 2013-03-26 16:43:00 --> Session Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Helper loaded: string_helper
DEBUG - 2013-03-26 16:43:00 --> Encrypt Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Database Driver Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Session routines successfully run
DEBUG - 2013-03-26 16:43:00 --> Model Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Model Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Helper loaded: date_helper
DEBUG - 2013-03-26 16:43:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-03-26 16:43:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-03-26 16:43:00 --> Helper loaded: form_helper
DEBUG - 2013-03-26 16:43:00 --> Form Validation Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Helper loaded: url_helper
DEBUG - 2013-03-26 16:43:00 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2013-03-26 16:43:00 --> Helper loaded: language_helper
DEBUG - 2013-03-26 16:43:00 --> Config Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Hooks Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Utf8 Class Initialized
DEBUG - 2013-03-26 16:43:00 --> UTF-8 Support Enabled
DEBUG - 2013-03-26 16:43:00 --> URI Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Router Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Output Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Security Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Input Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-26 16:43:00 --> Language Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Loader Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Controller Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2013-03-26 16:43:00 --> Email Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2013-03-26 16:43:00 --> Helper loaded: cookie_helper
DEBUG - 2013-03-26 16:43:00 --> Session Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Helper loaded: string_helper
DEBUG - 2013-03-26 16:43:00 --> Encrypt Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Database Driver Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Session routines successfully run
DEBUG - 2013-03-26 16:43:00 --> Model Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Model Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Helper loaded: date_helper
DEBUG - 2013-03-26 16:43:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-03-26 16:43:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-03-26 16:43:00 --> Helper loaded: form_helper
DEBUG - 2013-03-26 16:43:00 --> Form Validation Class Initialized
DEBUG - 2013-03-26 16:43:00 --> Helper loaded: url_helper
DEBUG - 2013-03-26 16:43:00 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2013-03-26 16:43:00 --> Helper loaded: language_helper
DEBUG - 2013-03-26 16:43:00 --> File loaded: application/views/auth/login.php
DEBUG - 2013-03-26 16:43:00 --> Final output sent to browser
DEBUG - 2013-03-26 16:43:00 --> Total execution time: 0.2251
DEBUG - 2013-03-26 16:43:13 --> Config Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Hooks Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Utf8 Class Initialized
DEBUG - 2013-03-26 16:43:13 --> UTF-8 Support Enabled
DEBUG - 2013-03-26 16:43:13 --> URI Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Router Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Output Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Security Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Input Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-26 16:43:13 --> Language Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Loader Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Controller Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2013-03-26 16:43:13 --> Email Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2013-03-26 16:43:13 --> Helper loaded: cookie_helper
DEBUG - 2013-03-26 16:43:13 --> Session Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Helper loaded: string_helper
DEBUG - 2013-03-26 16:43:13 --> Encrypt Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Database Driver Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Session routines successfully run
DEBUG - 2013-03-26 16:43:13 --> Model Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Model Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Helper loaded: date_helper
DEBUG - 2013-03-26 16:43:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-03-26 16:43:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-03-26 16:43:13 --> Helper loaded: form_helper
DEBUG - 2013-03-26 16:43:13 --> Form Validation Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Helper loaded: url_helper
DEBUG - 2013-03-26 16:43:13 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2013-03-26 16:43:13 --> Helper loaded: language_helper
DEBUG - 2013-03-26 16:43:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-03-26 16:43:13 --> Config Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Hooks Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Utf8 Class Initialized
DEBUG - 2013-03-26 16:43:13 --> UTF-8 Support Enabled
DEBUG - 2013-03-26 16:43:13 --> URI Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Router Class Initialized
DEBUG - 2013-03-26 16:43:13 --> No URI present. Default controller set.
DEBUG - 2013-03-26 16:43:13 --> Output Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Security Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Input Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-26 16:43:13 --> Language Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Loader Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Controller Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2013-03-26 16:43:13 --> Email Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2013-03-26 16:43:13 --> Helper loaded: cookie_helper
DEBUG - 2013-03-26 16:43:13 --> Session Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Helper loaded: string_helper
DEBUG - 2013-03-26 16:43:13 --> Encrypt Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Database Driver Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Session routines successfully run
DEBUG - 2013-03-26 16:43:13 --> Model Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Model Class Initialized
DEBUG - 2013-03-26 16:43:13 --> Helper loaded: date_helper
DEBUG - 2013-03-26 16:43:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-03-26 16:44:37 --> Config Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Hooks Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Utf8 Class Initialized
DEBUG - 2013-03-26 16:44:37 --> UTF-8 Support Enabled
DEBUG - 2013-03-26 16:44:37 --> URI Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Router Class Initialized
DEBUG - 2013-03-26 16:44:37 --> No URI present. Default controller set.
DEBUG - 2013-03-26 16:44:37 --> Output Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Security Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Input Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-26 16:44:37 --> Language Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Loader Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Controller Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2013-03-26 16:44:37 --> Email Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2013-03-26 16:44:37 --> Helper loaded: cookie_helper
DEBUG - 2013-03-26 16:44:37 --> Session Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Helper loaded: string_helper
DEBUG - 2013-03-26 16:44:37 --> Encrypt Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Database Driver Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Session routines successfully run
DEBUG - 2013-03-26 16:44:37 --> Model Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Model Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Helper loaded: date_helper
DEBUG - 2013-03-26 16:44:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-03-26 16:44:37 --> Helper loaded: url_helper
DEBUG - 2013-03-26 16:44:37 --> Config Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Hooks Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Utf8 Class Initialized
DEBUG - 2013-03-26 16:44:37 --> UTF-8 Support Enabled
DEBUG - 2013-03-26 16:44:37 --> URI Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Router Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Output Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Security Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Input Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-26 16:44:37 --> Language Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Loader Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Controller Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2013-03-26 16:44:37 --> Email Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2013-03-26 16:44:37 --> Helper loaded: cookie_helper
DEBUG - 2013-03-26 16:44:37 --> Session Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Helper loaded: string_helper
DEBUG - 2013-03-26 16:44:37 --> Encrypt Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Database Driver Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Session routines successfully run
DEBUG - 2013-03-26 16:44:37 --> Model Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Model Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Helper loaded: date_helper
DEBUG - 2013-03-26 16:44:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-03-26 16:44:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-03-26 16:44:37 --> Helper loaded: form_helper
DEBUG - 2013-03-26 16:44:37 --> Form Validation Class Initialized
DEBUG - 2013-03-26 16:44:37 --> Helper loaded: url_helper
DEBUG - 2013-03-26 16:44:37 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2013-03-26 16:44:37 --> Helper loaded: language_helper
DEBUG - 2013-03-26 16:44:37 --> File loaded: application/views/auth/login.php
DEBUG - 2013-03-26 16:44:37 --> Final output sent to browser
DEBUG - 2013-03-26 16:44:37 --> Total execution time: 0.2180
DEBUG - 2013-03-26 16:45:00 --> Config Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Hooks Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Utf8 Class Initialized
DEBUG - 2013-03-26 16:45:00 --> UTF-8 Support Enabled
DEBUG - 2013-03-26 16:45:00 --> URI Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Router Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Output Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Security Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Input Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-26 16:45:00 --> Language Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Loader Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Controller Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2013-03-26 16:45:00 --> Email Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2013-03-26 16:45:00 --> Helper loaded: cookie_helper
DEBUG - 2013-03-26 16:45:00 --> Session Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Helper loaded: string_helper
DEBUG - 2013-03-26 16:45:00 --> Encrypt Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Database Driver Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Session routines successfully run
DEBUG - 2013-03-26 16:45:00 --> Model Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Model Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Helper loaded: date_helper
DEBUG - 2013-03-26 16:45:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-03-26 16:45:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-03-26 16:45:00 --> Helper loaded: form_helper
DEBUG - 2013-03-26 16:45:00 --> Form Validation Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Helper loaded: url_helper
DEBUG - 2013-03-26 16:45:00 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2013-03-26 16:45:00 --> Helper loaded: language_helper
DEBUG - 2013-03-26 16:45:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-03-26 16:45:00 --> Config Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Hooks Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Utf8 Class Initialized
DEBUG - 2013-03-26 16:45:00 --> UTF-8 Support Enabled
DEBUG - 2013-03-26 16:45:00 --> URI Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Router Class Initialized
DEBUG - 2013-03-26 16:45:00 --> No URI present. Default controller set.
DEBUG - 2013-03-26 16:45:00 --> Output Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Security Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Input Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-26 16:45:00 --> Language Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Loader Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Controller Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2013-03-26 16:45:00 --> Email Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2013-03-26 16:45:00 --> Helper loaded: cookie_helper
DEBUG - 2013-03-26 16:45:00 --> Session Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Helper loaded: string_helper
DEBUG - 2013-03-26 16:45:00 --> Encrypt Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Database Driver Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Session routines successfully run
DEBUG - 2013-03-26 16:45:00 --> Model Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Model Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Helper loaded: date_helper
DEBUG - 2013-03-26 16:45:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-03-26 16:45:00 --> Helper loaded: url_helper
DEBUG - 2013-03-26 16:45:00 --> Config Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Hooks Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Utf8 Class Initialized
DEBUG - 2013-03-26 16:45:00 --> UTF-8 Support Enabled
DEBUG - 2013-03-26 16:45:00 --> URI Class Initialized
DEBUG - 2013-03-26 16:45:00 --> Router Class Initialized
DEBUG - 2013-03-26 16:45:01 --> Output Class Initialized
DEBUG - 2013-03-26 16:45:01 --> Security Class Initialized
DEBUG - 2013-03-26 16:45:01 --> Input Class Initialized
DEBUG - 2013-03-26 16:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-26 16:45:01 --> Language Class Initialized
DEBUG - 2013-03-26 16:45:01 --> Loader Class Initialized
DEBUG - 2013-03-26 16:45:01 --> Controller Class Initialized
DEBUG - 2013-03-26 16:45:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2013-03-26 16:45:01 --> Email Class Initialized
DEBUG - 2013-03-26 16:45:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2013-03-26 16:45:01 --> Helper loaded: cookie_helper
DEBUG - 2013-03-26 16:45:01 --> Session Class Initialized
DEBUG - 2013-03-26 16:45:01 --> Helper loaded: string_helper
DEBUG - 2013-03-26 16:45:01 --> Encrypt Class Initialized
DEBUG - 2013-03-26 16:45:01 --> Database Driver Class Initialized
DEBUG - 2013-03-26 16:45:01 --> Session routines successfully run
DEBUG - 2013-03-26 16:45:01 --> Model Class Initialized
DEBUG - 2013-03-26 16:45:01 --> Model Class Initialized
DEBUG - 2013-03-26 16:45:01 --> Helper loaded: date_helper
DEBUG - 2013-03-26 16:45:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-03-26 16:45:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-03-26 16:45:01 --> Helper loaded: form_helper
DEBUG - 2013-03-26 16:45:01 --> Form Validation Class Initialized
DEBUG - 2013-03-26 16:45:01 --> Helper loaded: url_helper
DEBUG - 2013-03-26 16:45:01 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2013-03-26 16:45:01 --> Helper loaded: language_helper
DEBUG - 2013-03-26 16:45:01 --> File loaded: application/views/auth/login.php
DEBUG - 2013-03-26 16:45:01 --> Final output sent to browser
DEBUG - 2013-03-26 16:45:01 --> Total execution time: 0.2205
