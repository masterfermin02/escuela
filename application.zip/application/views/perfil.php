<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />

<link type="text/css" href=<?php echo base_url("assets/css/style.css") ?> rel="stylesheet" media="screen" />
<link href="<?php echo base_url(); ?>public/css/flexigrid.css" rel="stylesheet" media="screen" type="text/css" />
<script type="text/javascript" src="<?php echo base_url(); ?>public/js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>public/js/flexigrid.js"></script>

<style type="text/css" >

    .grid-footer {
    position: relative;
    top: -28px;
    float : right;
    width : 100px;
    }

    .grid-footer .pGroup {
       padding-top: 5px;
    }
</style>
</head>
<body >
<div id="perfil-img"> 
        <img src="<?php echo base_url('imagenes/ebg.jpg')?>" /> 
</div>
        <h1 style="
    
"><?php echo $estu['nombre'].' '.$estu['apellido']; ?></h1> 
        <table>
            <tbody>
                <tr>
        <td>Matriculo	</td><td><?php echo $estu['idestudiante']?></td>
                </tr>
                <tr>
       <td> Familia	</td><td><?php echo $estu['apellido']?></td>
        </tr>
        <tr>
	<td>Direccion</td><td><?php echo $estu['direccion']?></td>
        </tr>
        <tr>
	<td>Telefono</td><td><?php echo $estu['telefono']?></td>
        </tr>
        <tr>
	<td>Celular</td><td><?php echo $estu['celular']?></td>
        </tr>
        <tr>
	<td>Fecha Nacimiento</td><td><?php echo $estu['fechanacimiento']?></td>
        </tr>
        <tr>
	<td>Edad</td><td><?php echo $estu['edad']?></td>
        </tr>
        <tr>
	<td>Enfermedades</td><td><?php echo $estu['enfermedades']?></td>
        </tr>
        <tr>
	<td>Estado Civil</td><td><?php echo $estu['estadocivil']?></td>
        </tr>
        <tr>
	<td>Sexo</td><td><?php echo $estu['sexo']?></td>
        </tr>
        <tr>
	<td>Estatus</td><td><a id="estado" href="#" ><?php echo $estu['estatus']?></a></td>
        </tr>
        <tr>
	<td>Fecha Ingreso</td><td><?php echo $estu['fechaingreso']?></td>
        </tr>
        <tr>
	<td>Nacionalidad</td><td><?php echo $estu['nacionalidad']?></td>
        </tr>
        <tr>
	<td>Observaciones</td><td><?php echo $estu['observaciones']?></td>
        </tr>
        <tr>
	<td>Monto Inscripcion</td><td><?php echo $estu['monto_inscripcion']?></td>
        </tr>
        <tr>
	<td>Pago Mensual</td><td><?php echo $estu['pago_mensual']?></td>
        </tr>
        <tr>
	<td>Fecha Primer Pago</td><td><?php echo $estu['fecha_primer_pago']?></td>
        </tr>
        <tr>
	<td>Monto Re-Inscripcion</td><td><?php echo $estu['monto_reinscripcion']?></td>
        </tr>
        <tr>
	<td>Nombre Pariente</td><td><?php echo $estu['nombre_pariente']?></td>
        </tr>
        <tr>
	<td>Telefono Pariente</td><td><?php echo $estu['telefono_pariente']?></td>
        </tr>
        
        </tbody>
        </table>
    <h1 style="
    
">Cuentas Pendientes</h1>
<table id="flex1"></table>
<h1 style="
    
">Grupo</h1> 
<script type="text/javascript">
   <?php echo $cuentas; ?>
       $("#estado").click(function(){
           $.ajax({
                type : "POST",
                url : "<?php echo site_url('perfil/change_estatus'); ?>",
                data : "id="+"<?php echo $estu['idestudiante']; ?>",
                success : function(data){
                    $('#estado').text(data);
                }
            });
       });
</script>
