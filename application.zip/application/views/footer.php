
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery-1.12.3.min.js'); ?>"></script>
<script src=<?php echo base_url("js/jquery.maskedinput.js") ?> type="text/javascript"></script>
<script src=<?php echo base_url("js/jquery.autocomplete.js") ?> type="text/javascript"></script>
<script type="text/javascript" >
 jQuery(function($){
        $("#field-telefono").mask("(999)999-9999");
    });
	jQuery(function($){
        $("#field-celular").mask("(999)-999-9999");
    });
	jQuery(function($){
        $("#field-cedula").mask("999-9999999-9");
    });
	jQuery(function($){
        $("#field-telefono_empresa").mask("(999)-999-9999");
    });
	jQuery(function($){
        $("#field-telefono_pariente").mask("(999)-999-9999");
    });

$(document).ready(function(){
	$("#field-fechanacimiento").change(function () {
			var fecha_actual = new Date();
			var fecha_nacimiento = $("#field-fechanacimiento").val();
			fecha_nacimiento = fecha_nacimiento.substr(6,4);
			var edad = fecha_actual.getFullYear() - fecha_nacimiento;
		  $("#field-edad").val(edad);
	});
});
	
	</script>
<script type="text/javascript" src="<?php echo base_url('assets/grocery_crud/texteditor/ckeditor/ckeditor.js'); ?>" ></script>
<script type="text/javascript">
	
	(function($){
		$(document).ready(function($) {
			
		});
			
		
	
	}(jQuery));

</script>
<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
</body>
</html>