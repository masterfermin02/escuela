
<?php
echo '<img src='.base_url("imagenes/ebg.jpg").' width=800 height=800 />';

?>