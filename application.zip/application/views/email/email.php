
<div class="page-header">
  <h1>Administrador de correo <small>EBG</small></h1>
</div>
<div class="panel panel-primary">
  <div class="panel-heading">Creando correo</div>
  <div class="panel-body">
	<form action="<?php echo base_url('index.php/email/send'); ?>" method="post" >
  	<div class="form-group">
  		<label for="titulo" class="col-sm-2 control-label">Titulo:</label>
	    <input type="text" class="form-control" name="titulo" />
  	</div>
  	<div class="form-group">
  		<label for="para" class="col-sm-2 control-label">Para:</label>
	    <input type="text" class="form-control" name="para" />
  	</div>
	<div>
		<label class="col-sm-2 control-label" >Grupos</label>
		<select name="grupos[]" class="form-control" id="grupos" multiple >
			<?php 
				foreach($grupos as $grupo)
				{
					echo '<option value="'.$grupo['id_nivel'].'" >'.$grupo['libro'].'</option>';
				}
			?>
		</select>
		
	</div>
  	<div class="form-group">
	  	<label for="mesanje" class="col-sm-2 control-label">Mensaje:</label>
	    <textarea class="form-control" name="msj" rows="3" >
	    	</textarea>
    </div>
    <div class="form-group">
    	<button class="pull-right btn btn-success" >Enviar</button>
    </div>
	</form>
  </div>
</div>

<script >
	
 </script>

