<?php echo '<h1 style="text-align: left;">'.$title.'</h1>'; ?>
