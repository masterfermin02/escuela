<?php

 header("Content-Type: application/vnd.ms-excel");
    
    header("Expires: 0");
    
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    
    header("content-disposition: attachment;filename=grupos.xls");
?>
<html>

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Grupos</title>

<style type="text/css">

<!–

.style1 {

font-family: Verdana, Arial, Helvetica, sans-serif;

font-weight: bold;

}

.style2 {font-family: Verdana, Arial, Helvetica, sans-serif}

–>

</style>

</head>

<body>
<table id="box-table-a" style="margin-left: auto;  margin-right: auto;">
<thead >
<tr>
	<th >Nombre</th>
  <th>Dirección</th>
  <th>Teléfono</th>
  <th>Celular</th>
  <th >Fecha Nacimiento</th>
  <th >Edad</th>
  <th >Monto Reinscripción</th>
</tr>
</thead>
<tbody style="background-color:#0099CC; color: #800080; ">
<?php foreach ($estudiantes as $items): ?>

	<tr>
		<td>
			<?php echo $items->nombre." ".$items->apellidos ?>
		</td>
	   <td>
		<?php echo $items->direccion ?>

	  </td>
        <td>
		<?php echo $items->telefono ?>

	  </td>
        <td>
		<?php echo $items->celular ?>

	  </td>
	  <td>
		<?php echo date("d-m-Y", strtotime($items->fechanacimiento)); ?>

	  </td>
	  <td>
		<?php echo $items->edad; ?>

	  </td>
	  <td ><?php echo $items->monto_reinscripcion; ?></td>
	  
	</tr>

<?php endforeach; ?>
<tbody>
</table>
</body>
</html>