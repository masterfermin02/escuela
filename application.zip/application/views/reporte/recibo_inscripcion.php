<?php
$handle = fopen("data", "w");
    //if(() === FALSE){
      //  die('No se puedo Imprimir, Verifique su conexion con el Terminal');
    //}



fwrite($handle,chr(27). chr(64));//reinicio

//fwrite($handle, chr(27). chr(112). chr(48));//ABRIR EL CAJON
fwrite($handle, chr(27). chr(100). chr(0));//salto de linea VACIO
fwrite($handle, chr(27). chr(33). chr(8));//negrita
fwrite($handle, chr(27). chr(97). chr(1));//centrado
	
    fwrite($handle,fill_space("",80));
    fwrite($handle,fill_space("",27)."EBG LANGUAGE CENTER ( L.C)".fill_space("",27));
    fwrite($handle,fill_space("",26)."SHARING KNOWLEDGE WITH PRIDE".fill_space("",26));
    fwrite($handle,"             Carretera Luperon # 43 km 2 , Gurabo, Santiago R. D                ");
    fwrite($handle,"    Correo electronico: ebglanguagecenter@gmail.com, Tel: 809-581-5555          ");
    $hora = getdate(time());
    fwrite($handle,fill_space("Fecha : ".date('d-m-Y')." ".$hora["hours"].":".$hora["minutes"].":".$hora["seconds"],80));
    fwrite($handle,"=====================RECIBO DE PAGO Y MESUALIDAD================================");
    fwrite($handle,  fill_space("Numero Recibo  : ".$secuencia,80));
    fwrite($handle,  fill_space("Familia   : ".$familia,80));
    fwrite($handle,  fill_space("Direccion : ".$direccion,80));
    fwrite($handle,  fill_space("Telefono  : ".$telefono,80));
    fwrite($handle,"================================================================================");
    fwrite($handle,"Matricula Nombre                   Unidad Actual  Monto Inscripcion             ");
    fwrite($handle, fill_space($results[0],9)." ".fill_space($results[1],25)." ".fill_space($results[2],13)." ".fill_space($results[3],30));
    fwrite($handle,fill_space('Total Recibido : $ '.number_format($monto_total),80));
    fwrite($handle,fill_space("",80));
    fwrite($handle,fill_space("",80));
    fwrite($handle,"______________                                                                  ");
    fwrite($handle,"Realizado Por".fill_space("",67));
    
    fclose($handle); // cierra el fichero PRN
    //shell_exec('lpr lpt1'); //lpr->puerto impresora, imprimir archivo PRN
	$fh = fopen('data', "rb");

//$content = fread($fh, getRemoteFileSize($nombre_archivo));
$content = fread($fh, filesize('data')); //filesize
fclose($fh);



$ph = printer_open('Epson');
printer_set_option($ph, PRINTER_MODE, "RAW");

//printer_start_doc($ph, "My Document");
//printer_start_page($ph);

printer_write($ph, $content);

//printer_end_page($ph);
//printer_end_doc($ph);
printer_close($ph);
	redirect('/');
    
 ?>