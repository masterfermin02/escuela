<script>
$(document).ready(function(){
	$(".DTTT_button_filter_status").click(function(){
		if($(this).text() == "Activos"){
			$(".search_estatus").val("");
			$(this).text('Muestra Todos');
			$(".search_estatus").trigger("change");
		}else{
			$(".search_estatus").val("Activo");
			$(this).text('Activos');
			$(".search_estatus").trigger("change");
		}
	});
});
</script>
<div>
<!--<a class="DTTT_button ui-button ui-state-default DTTT_button_filter_status"style="
    position: absolute;
    right: 120px;
    top: 163px;
	z-index: 10;
" id="ToolTables_groceryCrudTable_1" href="pago/activo" ><span>Muestra Todos</span></a>-->
		<?php echo $output; ?>
		
    </div>
	<div class="grid-footer flexigrid">
    <div class="btnseparator"></div>
    <div class="pGroup">
    <span class="pPageStat">
     <?php if(isset($total))
		echo "Total : ".$total;
	?>
    </span>
    </div>
</div>
